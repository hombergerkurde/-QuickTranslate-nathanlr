# 📤 UPLOAD ANLEITUNG

## 🎯 Altes Repository löschen (Optional):

Falls du das alte Repository löschen möchtest:
1. Gehe zu Settings → Danger Zone → Delete Repository

---

## 🆕 Neues Repository erstellen:

1. **GitHub.com** → **[+]** → **"New repository"**
2. **Name:** `QuickTranslate`
3. **Description:** `iOS Translation Tweak for nathanlr rootless`
4. ☑ **Add a README file**
5. **"Create repository"**

---

## 📦 Dateien hochladen:

### **Wichtig: ALLE diese Dateien hochladen!**

1. **Gehe zu deinem neuen Repository**
2. **"Add file"** → **"Upload files"**
3. **Entpacke** `QuickTranslate-nathanlr-FINAL.zip`
4. **Markiere ALLE Dateien** im Ordner:
   - ✅ Tweak.x
   - ✅ Makefile
   - ✅ control
   - ✅ QuickTranslate.plist
   - ✅ README.md
   - ✅ layout/ (ganzer Ordner!)
   - ✅ .github/ (ganzer Ordner!)

5. **Ziehe alle in GitHub-Fenster**
6. **"Commit changes"**

---

## ⏳ Warten auf Build:

1. **Gehe zu "Actions"** Tab
2. Build startet automatisch (~3-4 Minuten)
3. Warte auf **grünen Haken** ✅

---

## 📥 .deb herunterladen:

1. **Klicke auf den erfolgreichen Build**
2. **Scrolle zu "Artifacts"**
3. **Klicke auf "QuickTranslate-nathanlr-v2.1"**
4. **ZIP wird heruntergeladen**
5. **Entpacken** → .deb ist drin!

---

## 📱 Auf iPhone installieren:

### **Mit Filza:**
1. Kopiere .deb auf iPhone
2. Öffne Filza
3. Tippe auf .deb → "Install"
4. "Respring"

### **Mit Terminal:**
```bash
dpkg -i com.hombergerkurde.quicktranslate_2.1.0_iphoneos-arm64.deb
killall -9 SpringBoard
```

---

## ✅ Testen:

1. **Safari öffnen**
2. **Text markieren**
3. **"🌐 Übersetzen"** sollte erscheinen!
4. **Einstellungen → QuickTranslate** sollten sich öffnen!

---

**Viel Erfolg!** 🚀
